

// adavatage of that us can decribe same as array mixed properties


var tuble: [number,string]  =[1,"shah"];
var secondElemnent = tuble[1];// out get string

