

/// type strong
var a: string ="gold";
a = "james";
var b : boolean = true;
var c : number = 7;

// type interfarncc
 a = "shah";

 var g = true ;


