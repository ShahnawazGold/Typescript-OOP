var a = 4;
//const b = 5;
//const c = "shah" ;
if (true) {
    //z
    var z = 4;
}
else {
}
console.log("let" + z);
