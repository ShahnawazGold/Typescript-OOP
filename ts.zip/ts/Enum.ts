

enum Color {red,blue,green};
var c :Color= Color.green;