function callBacxk(text) {
    console.log("inside text" + Text);
}
function calling(intialText, callBacxk) {
    callBacxk(intialText);
}
calling("calinf", "calbck");
