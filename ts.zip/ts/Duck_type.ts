
let mytpe = {name:"shah",id:4 };


mytype ={id:4 ,name ="ss"};


var x : { id :number ,[x:string] :any} ;

x= {id :3, fulname = "sggg"};