function add(arg1, agr2) {
    //return arg1+arg2;
}
console.log(add(2, 4));
console.log(add("hrll", "shah"));
console.log(add(false, true));
