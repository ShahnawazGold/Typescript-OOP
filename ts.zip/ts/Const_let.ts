
const a : number = 4;
//const b = 5;
//const c = "shah" ;


if (true) {
    //z
    let z =4;

} else {
    //let strin
   // let z = "string";
    
}
console.log("let"+z);
