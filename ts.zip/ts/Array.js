var array1 = [1, 4, 5, 7];
console.log(array1[2]);
var b = [2, 3, 5];
var array4 = []; // EMPT
var array5 = []; //DYNMOC
array1.push(777); // dymic
