var mytpe = { name: "shah", id: 4 };
mytype = { id: 4, name: name };
var x;
x = { id: 3, fulname: fulname };
