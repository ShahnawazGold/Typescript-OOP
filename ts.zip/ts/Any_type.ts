


let a : any ={name :"sss",id:3}; // id 

a = {name :"sssd",id:4};
a= {name:"shh", gender: true};

a ="this is devemnt site god";// string


a= function  () 
{
    console.log("know as typing"); ///string
}
