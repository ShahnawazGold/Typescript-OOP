function add(a, b) {
    return a + b;
}
var add1 = function add(a, b) {
    return a + b;
};
var add2 = function add(a, b) {
    return a + b;
};
var add3 = function add(a, b) {
    return a + b;
};
var add4 = function (a, b) { return a + b; }; // lamda function
