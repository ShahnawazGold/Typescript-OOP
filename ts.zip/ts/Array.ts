


let array1 : Number[] =[1,4,5,7];
console.log(array1[2]);


let b : Array<Number> = [2,3,5];


let array4 : Number[] =[];// EMPT

let array5 : Number[] =[];//DYNMOC
 array1.push(777); // dymic