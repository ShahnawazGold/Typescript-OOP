/// type strong
var a = "gold";
a = "james";
var b = true;
var c = 7;
// type interfarncc
a = "shah";
var g = true;
