

function add(arg1:string,agr2 :string):string 
function add(arg1:number,agr2 :number):Number
 function add(arg1:Boolean,agr2 :boolean):boolean

 function add(arg1:any, agr2:any):any 
 {
     //return arg1+arg2;
 }
    
console.log(add(2,4));
console.log(add("hrll","shah"));
console.log(add(false,true));